package interfaces;

public interface ISala {

	void setSala(String nome);
	
	void setCapacidade(int qtdParticipantes);
	
	String getSala();
	
	int getCapacidade();
}
