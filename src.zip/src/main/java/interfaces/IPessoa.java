package interfaces;


public interface IPessoa {

	void setName(String nome);
	
	void setSobrenone(String sobrenome);
	
	String getName();
	
	String getSobrenome();
}
