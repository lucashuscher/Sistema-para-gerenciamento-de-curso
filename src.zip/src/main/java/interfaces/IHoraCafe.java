package interfaces;

public interface IHoraCafe {

	void setSala(String nome);
	
	void setCapacidade(int capacidade);
	
	String getSala();
	
	int getCapacidade();
	
}
